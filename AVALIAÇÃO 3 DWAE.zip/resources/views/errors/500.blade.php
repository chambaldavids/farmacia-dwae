<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erro interno · Farmácia DWAE</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex align-items-center justify-content-center vh-100 bg-light">
    <div class="text-center px-3">
        <h1 class="display-3 fw-bold text-danger">500</h1>
        <p class="fs-5">Ocorreu um erro interno no servidor. A equipa técnica já foi notificada.</p>
        <a href="{{ url('/dashboard') }}" class="btn btn-primary">Voltar ao painel</a>
    </div>
</body>
</html>
